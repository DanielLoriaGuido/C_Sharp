﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Wizard : Person, IFlyer
    {
        //Person PrintStatusを変更します
        public override void PrintStatus()
        {
            Console.Write($"私は魔法使いの {Name} で、");
            Console.WriteLine($"パワーは {Power} です。");
        }
        public void MakeMagic()
        {
            Console.WriteLine($"{Name} は魔法を使いました。");
        }
        public void Fly()
        {
            Console.WriteLine($"{Name} は空を飛びました。");
        }
    }
}
