﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    //商人クラス
    //  人間 Person に、商人の機能を追加したクラス
    class Trader : Person
    {
        //商人で追加・変更するメンバー

        //取引する（メソッド）
        public void DoTrade()
        {
            Console.WriteLine($"{Name} は取引をしました。");
        }

        //PersonのPrintStatusの機能を変更する
        //override 基底クラスのvirtual/abstract を変更する

        public override void PrintStatus()
        {
            Console.Write($"私は商人の {Name} で、");
            Console.WriteLine($"パワーは {Power} です。");
        }
    }
}
