﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    //飛ぶ者　（インタフェース）

    //インタフェースのインスタンスは作れない
    interface IFlyer
    {
        //メンバ－は、必ず派生クラスで記述しなければならない

        void Fly(); //飛ぶ（メソッド）
    }
}
