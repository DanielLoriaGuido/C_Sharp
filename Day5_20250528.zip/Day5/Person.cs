﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    // 人間クラス（人間として共通部分）
    //abstract: インスタンスを作れないようにする

    abstract class Person
    {
        //人数（インスタンスの数）を記憶するフィールド
        private static int _count = 0;
        //人数を表示する（メソッド）
        public static void PrintCount()
        {
            Console.WriteLine($"人数は {_count} 人です。");
        }

        //コンストラクター（メソッド）
        public Person()
        {
            //インスタンスの初期化の処理
            _count++; //人数を１増やす
        }

        //歩く（メソッド）
        //  歩くとパワーが減る
        public void Walk()
        {
            const int WALK_POWER = 20;//歩くのに必要なパワー

            if (Power < WALK_POWER)
            {
                Console.WriteLine($"{Name} は歩けません。");
            }
            else
            {
                Console.WriteLine($"{Name} は歩きました。");
                Power = Power - WALK_POWER;//パワーを減らす
            }
        }


        // クラスの中身

        //名前（最初にセットして、後から変更できない）
        //private string _name;
        //名前（自動実装のプロパティ）
        public string Name
        {
            init; // { _name = value; }
            get; // { return _name; }
        }

        //パワー（マイナスにならない）
        private int _power;
        //パワー（プロパティ）
        public int Power
        {
            set //値をセットするときの手続き（setter）
            {
                if (value < 0) value = 0;
                _power = value;
            }
            get //値を取り出すときの手続き（getter）
            {
                return _power;
            }
        }

        //パワーをセットするメソッド
        public void SetPower(int value)
        {
            if (value < 0) value = 0; //マイナスなら０に置き換える
            _power = value;
        }
        //パワーを得るためのメソッド
        public int GetPower()
        {
            return _power;
        }

        //状態を表示する
        public abstract void PrintStatus();
    }//クラスの終わり
}//名前空間の終わり
