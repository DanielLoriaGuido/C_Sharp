﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Dragon : IFlyer
    {
        //火を吐く
        public void SpitFire()
        {
            Console.WriteLine("ドラゴンは火を吐きました。");
        }
        //飛ぶ
        public void Fly()
        {
            Console.WriteLine("ドラゴンは空を飛びました。");
        }
        //吠える
        public void Roar()
        {
            Console.WriteLine("ドラゴンは吠えました。");
        }
    }
}

