﻿using Day5; //Day5を省略できる

Trader tommy = new Trader()
{
    Name = "TOMMY",
    Power = 150,
};

Wizard willy = new Wizard()
{
    Name = "WILLY",
    Power = 200,
};

// Personの配列
Person[] people = new Person[]
{
    tommy, // Trader（アップキャスト）
    willy // Wizard（アップキャスト）
};

foreach (Person p in people)
{
    p.PrintStatus();
    p.Walk();
    p.PrintStatus();

    if(p is Trader)
    {
        Trader t = (Trader)p; //ダウンキャスト  down cast
        t.DoTrade();
    }

    if (p is Wizard)
    {
        Wizard w = (Wizard)p; //ダウンキャスト  down cast
        w.MakeMagic();
        w.Fly();
    }

    Console.WriteLine();//改行
}

Dragon dra = new Dragon();
    dra.SpitFire();
    dra.Fly();
    dra.Roar();

//IFlyerの配列
IFlyer[] flyers = new IFlyer[]
{
    willy, // Wizard（アップキャスト）
    dra,   // Dragon（アップキャスト）
};

foreach (IFlyer f in flyers)
{
    Console.WriteLine();//改行
    f.Fly();  //IFlyerの機能を呼ぶ
    
}
