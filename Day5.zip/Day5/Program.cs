﻿using Day5;//Day5を省略できます
//人間のクラスを使います

//Personのオブジェクトを作ります
//　　　インスタンス instance を作ります

Person alice = new Person()
{
    Name = "ALICE",
    Power = 100
};
//alice.Name = "ALICE";
//alice.Power = 100; //プロパティを使います
//alice.Name = "アリス"; これを禁止したいです
alice.PrintStatus(); //メンバーを使います


Person bob = new Person()
{
    Name = "BOB",
    Power = -50
};
//bob.Name = "BOB";
//bob.Power = -50; 
bob.PrintStatus(); 