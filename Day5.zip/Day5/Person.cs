﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    // 人間クラス (ゲームの中のキャラクター)
    class Person
    {
        // クラスの中身
        // 情報
        //名前　　(最初にセットして、後から変更できない)
        //private string _name;
        //名前　(自動実装プロパティ）　
        public string Name
        {
            init; //{ _name = value; }
            get; //{ return _name; }
        }

        //パワー (マイナスになりません
        private int _power;
        //パワーをセットするのメソッド

        //パワー　（プロパティ）
        public int Power  //プロパティを作ります  
        {
            set
            {
                if (value < 0) value = 0; 
                _power = value;
            }
            get
            {
                return _power;
            }
        }

        //操作
        //状態を表示します
        public void PrintStatus()
        {
            //自分のメンバーなので、メンバー名だけOKです
            //自分　＝thisを書いて構いません
            Console.WriteLine($"私の名前は　{Name} です。");
            Console.WriteLine($"パワーは {_power} です。");
        }
    }//クラスの終わりです
}//名前空間の終わりです
