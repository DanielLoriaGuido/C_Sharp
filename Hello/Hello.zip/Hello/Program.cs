﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("こんにちは1");
Console.WriteLine("こんにちは2");
Console.WriteLine("こんにちは3");
Console.WriteLine("こんにちは4");




